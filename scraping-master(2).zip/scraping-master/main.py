from requests import get
from bs4 import BeautifulSoup
import csv
from os import path

class A:
	url = ['www.glendowercapital.com','www.aberdare.com','www.aberdeenstandard.com','www.abingworth.com',
	'www.act.is','www.aislingcapital.com','www.altariscap.com','www.altos.vc','www.americanindustrial.com',
	'www.aquacapital.net','www.artiman.com','www.athenianvp.com','www.avistacap.com','www.baincapitalventures.com','www.bayside.com',
	'www.bluepointcapital.com','www.braemarenergy.com','www.butlercapitalpartners.com',
	'www.capitalspring.com','www.capvest.co.uk','www.catalystprincipal.com',
	'www.cepfunds.com','www.champequity.com.au','www.chartwellinvestments.com','www.cheynecapital.com',
	'www.cidcap.com','www.clearstone.com','www.clearwatercp.com','www.commonwealthvc.com','www.comvest.com','www.convergencevc.com','www.corinthiancap.com',
	'www.cortecgroup.com','www.crossoceanpartners.com','www.crp.com','www.darwinpe.com',
	'www.drivecapital.com','www.ecm-pe.de','www.escalatecapital.com','www.essexapartmenthomes.com','www.ethos.co.za','www.excellerepartners.com',
	'www.falconinvestments.com','www.fimi.co.il',
	'www.flagshippioneering.com','www.fletcherspaght.com','www.fordfundlp.com','www.foresightgroup.eu','www.foundrygroup.com',
	'www.fountainvest.com','www.franklinparkllc.com','www.frontiercapital.com','www.ftvcapital.com']
	

	

	
	def request(self):
		b=[]
		for x in self.url:
			c='http://'+x
			response = get(c)
			b.append(response.content)
		return b

	def parser(self):
		lis=[]
		x=self.request()
		i=0
		
		while i<len(x):	
			soup = BeautifulSoup(x[i],'html.parser')
			a=soup.p
			b=soup.title
			
			title=(b.get_text())

			para=(a.get_text())
			
			a={'desc':para,"title":title,"managerurl":self.url[i]}
			print(a)
			lis.append(a)
			i=i+1
		
		return lis

	def write_csv(self):
		with open('data2.csv','w') as file:
			fields=['title','desc','managerurl']
			writer=csv.DictWriter(file,fieldnames=fields)
			writer.writeheader()
			
			
			a=self.parser()
			
			i=0
			# writer.writerow(["your", "header", "foo"])  # write header
			while i<len(a):
			
				writer.writerows([a[i]])
				i=i+1




a=A()
a.write_csv()



